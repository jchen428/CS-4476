Instruction for running code:

1.	Open proj2.m in MATLAB.
2.	Set current folder to ../code/.
3.	Click Run or press F5.
4.	To change the image pairs used, comment out the currently used
	image1, image2, and eval_file (if applicable) and uncomment the
	those variables for the desired image pair.