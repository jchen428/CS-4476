Instruction for running code:

1.	Open proj6_part1.m and/or proj6_part2.m in MATLAB.
2.	Set current folder to code/.
3.	Click Run or press F5.