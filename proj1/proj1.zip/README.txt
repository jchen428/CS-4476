Instruction for running code:

1.	Open proj1.m in MATLAB.
2.	Set current folder to code/.
3.	Click Run or press F5.
4.	To change the images, set the file paths for image1 and image2 to the paths 
	of the desired images. Matching image pairs (in order) are listed under 
	"%% Filtering and Hybrid Image construction", along with their proper 
	cutoff_frequency value.